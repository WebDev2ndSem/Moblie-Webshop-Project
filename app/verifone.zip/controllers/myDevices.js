var args = arguments[0] || {};
$.myDevices.open() ;

