var args = arguments[0] || {};
$.index.open() ;

