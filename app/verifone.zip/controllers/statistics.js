var args = arguments[0] || {};
$.statistics.open() ;