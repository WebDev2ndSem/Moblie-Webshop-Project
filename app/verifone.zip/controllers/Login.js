// MENU REDIRECTS

function openStats() {};
function openHelp() {};
function openMyDev() {};

// INITIAL LOGIN FUNCTION
function doLogin(e){
	Ti.App.Properties.removeProperty('username');
	Ti.App.Properties.removeProperty('password');
	Ti.App.Properties.setString('username', $.username.value);
	Ti.App.Properties.setString('password', $.password.value);
   var args = arguments[0] || {};
	var collection = Alloy.Collections.login;
	collection.fetch({ 
	    success : function(){
	    	$.login.visible = false;
	    	$.menu.visible = true;
	        _.each(collection.models, function(element, index, list){
	            
	            // We are looping through the returned models from the remote REST API
	            // Implement your custom logic here
	        });
	    },
	    error : function(){
		    $.login.visible = true;
		    $.loginError.visible = true;

   

	    }
	});
};

function openStatistics (){
Alloy.createController('statistics').getView().open();
}
function openHelp (){
Alloy.createController('getHelp').getView().open();
}
function openMyDev (){
Alloy.createController('myDevices').getView().open();
}

/*
$.productTableView.addEventListener('click', function(_event) {
    // get the correct model
    var model =
        Alloy.Collections.ProductCollection.getByCid(_event.rowData.productId);
    // create the controller and pass in the model
    var detailController = Alloy.createController('productDetail', {
        data : model
    });
    // get view returns the root view when no view ID is provided
    detailController.getView().open({
        modal : true
    });
});
*/



/*
function transform(model) {
    // Need to convert the model to a JSON object
    var prodObject = collection;
    return {
        "title" : prodObject.node_title + " by " + prodObject.productprice,
        "id" : prodObject.nid
    };
}*/