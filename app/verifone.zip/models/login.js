var username = Ti.App.Properties.getString('username');
var password = Ti.App.Properties.getString('password');
var authstr = 'Basic ' + Titanium.Utils.base64encode(username + ':' + password);

exports.definition = {  
    config: {
        "URL": "http://old.muranddesign.com/verifone/loggedin",
        "debug": 1, 
        "adapter": {
            "type": "restapi",
            "collection_name": "login",
            "idAttribute": "nid"
        },
        "headers": { // your custom headers
            "Accept": "application/json",
            "Authorization": authstr //"Basic dGVzdDp0ZXN0MQ=="
           // "X-StackMob-API-Key": "your-stackmob-key"
            
        },
       // "parentNode": "results" //your root node
    },      
    extendModel: function(Model) {      
        _.extend(Model.prototype, {});
        return Model;
    },  
    extendCollection: function(Collection) {        
        _.extend(Collection.prototype, {});
        return Collection;
    }       
};

